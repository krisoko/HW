import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		String izraz=in.next();
		for(int i=0;i<izraz.length();i++)
		{
			if(izraz.charAt(i)=='+')
			{
				System.out.println(Integer.parseInt(izraz.substring(0,i))+
						Integer.parseInt(izraz.substring(i+1,izraz.length())));
			}
		}
		//System.out.println(a+" "+op+" "+b+" = " );
	}

}
